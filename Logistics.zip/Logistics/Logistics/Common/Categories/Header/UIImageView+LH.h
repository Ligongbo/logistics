//
//  UIImageView+Common.h
//  XMPPIOS
//
//  Created by 王 晓明 on 13-11-29.
//  Copyright (c) 2013年 Dawn_wdf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Common)
- (void)setShoulderWithInteger:(NSInteger)integer;
@end
